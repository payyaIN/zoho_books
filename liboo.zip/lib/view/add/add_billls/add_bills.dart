// lib/view/add/add_billls/add_bills.dart
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:payzo_books/data/repository/add_bills/generate_bill_repository.dart' hide generateBillProvider;
import 'package:payzo_books/data/repository/add_bills/get_all_bills_repository.dart';
import 'package:payzo_books/data/repository/add_bills/get_branch_list_repository.dart';
import 'package:payzo_books/data/repository/add_bills/get_item_repository.dart';
import 'package:payzo_books/data/repository/add_bills/get_price_currency_repository.dart';
import 'package:payzo_books/data/repository/add_bills/get_unit_list_repo.dart';
import 'package:payzo_books/data/repository/add_bills/get_vendor_list_repository.dart';
import 'package:payzo_books/data/repository/add_bills/shipping_method_repository.dart';
import 'package:payzo_books/data/repository/add_invoice/get_tax_list_repo.dart';
import 'package:payzo_books/data/repository/bills_api/bills_api.dart';
import 'package:payzo_books/import_data.dart';
import 'package:payzo_books/view/add/add_billls/notifier/add_bill_form_notifier.dart';
import 'package:payzo_books/view/add/add_billls/widgets/bill_total_widget.dart';
import 'package:payzo_books/view/add/add_billls/widgets/item_details_add_bills.dart';
import 'package:payzo_books/utils/common_widgets/payzo_progress.dart';
import 'package:payzo_books/view/main_screen/notifiers/bottom_nav_bar_notifier.dart';

import '../../../data/repository/add_bills/add_bills_repository.dart';
import '../../../utils/focus_utility/focus_utility.dart';

class AddBills extends ConsumerStatefulWidget {
  const AddBills({super.key});

  @override
  ConsumerState<AddBills> createState() => _AddBillsState();
}

class _AddBillsState extends ConsumerState<AddBills> {
  bool _initialized = false;
  List<List<TextEditingController>> itemControllers = [];
  List<TextEditingController> billDetailsControllers = [
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
  ];

  List<TextEditingController> _createControllersForItem() {
    return [
      TextEditingController(), // 0 -> quantity
      TextEditingController(), // 1 -> rate
      TextEditingController(), // 2 -> amount (readOnly usually)
      TextEditingController(), // 3 -> itemName
      TextEditingController(), // 4 -> itemName (duplicate in original)
    ];
  }

  void _addControllersForNewItem() {
    itemControllers.add(_createControllersForItem());
    setState(() {}); // trigger rebuild so new controllers are passed to item widget
  }

  void _disposeControllersForItemAt(int index) {
    if (index < 0 || index >= itemControllers.length) return;
    for (var c in itemControllers[index]) {
      c.dispose();
    }
    itemControllers.removeAt(index);
    setState(() {});
  }

  void _disposeAllItemControllers() {
    for (var list in itemControllers) {
      for (var c in list) {
        c.dispose();
      }
    }
    itemControllers.clear();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
    ));
    if (!_initialized) {
      Future.microtask(() async {
        final itemDetails = ref.read(addBillFormProvider).itemDetails;

        // Ensure at least one item exists in state
        if (itemDetails.isEmpty) {
          ref.read(addBillFormProvider.notifier).addNewItem();
        }

        // Ensure controllers count matches items count
        if (itemControllers.length < ref.read(addBillFormProvider).itemDetails.length) {
          final missing = ref.read(addBillFormProvider).itemDetails.length - itemControllers.length;
          for (var i = 0; i < missing; i++) {
            _addControllersForNewItem();
          }
        }

        // initialize first line amount if null
        if (ref.watch(addBillFormProvider).itemDetails.isNotEmpty &&
            ref.watch(addBillFormProvider).itemDetails[0].amount == null) {
          ref.read(addBillFormProvider.notifier).updateItemField(0, 'amount', 0.00);
        }

        // 🔄 Fetch all required data (kick off providers)
        ref.read(fetchItemListProvider);
        ref.read(fetchAccountListProvider);
        ref.read(fetchUnitListProvider);
        ref.read(fetchBranchListProvider);
        ref.read(fetchShippingMethodsProvider);
        ref.read(fetchPriceCurrencyProvider);
        ref.read(fetchAllTaxesProvider);
        ref.read(getVendorList);

        // mark as initialized
        _initialized = true;
      });
    }
  }

  Future<void> clearFormAndControllers() async {
    final notifier = ref.read(addBillFormProvider.notifier);

    // Dispose all item controllers
    _disposeAllItemControllers();

    // Clear bill controllers
    for (var c in billDetailsControllers) c.clear();

    // Clear form state
    notifier.clearForm();

    // Reset to single line item in state + controllers
    notifier.addNewItem();
    _addControllersForNewItem();

    ref.read(addNewLineProvider.notifier).state = 1;

    // 🧹 Clear all form data (again, to ensure defaults)
    notifier.clearForm();

    // 🔁 Reset to just one line item
    notifier.addNewItem();

    // 🧮 Reset any state counter if you're using it elsewhere
    ref.read(addNewLineProvider.notifier).state = 1;

    // set sensible defaults: shipping method name and currency value
    try {
      final shippingMethods = await ref.read(fetchShippingMethodsProvider.future);
      final landFreight = shippingMethods.firstWhere(
            (method) => method.shpmName == "Land Freight",
        orElse: () => shippingMethods.first,
      );
      // IMPORTANT: notifier.updateField expects 'shippingMethod' string; notifier should handle it.
      notifier.updateField('shippingMethod', landFreight.shpmName ?? '');
    } catch (e) {
      debugPrint('Failed to set default shipping method: $e');
    }

    // Set default price currency "SAR" (string value) — mapper converts it to id
    try {
      final currencyList = await ref.read(fetchPriceCurrencyProvider.future);
      final sarCurrency = currencyList.firstWhere(
            (currency) => currency.currencyValue == "SAR",
        orElse: () => currencyList.first,
      );
      // notifier.updateField expects 'currency' string; mapper will look up id from this value.
      notifier.updateField('currency', sarCurrency.currencyValue ?? '');
    } catch (e) {
      debugPrint('Failed to set default currency: $e');
    }
  }

  @override
  void dispose() {
    _disposeAllItemControllers();
    for (var c in billDetailsControllers) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(addBillFormProvider);
    final notifier = ref.read(addBillFormProvider.notifier);

    return ScalingFactor(
      child: PopScope(
        onPopInvokedWithResult: (didPop, result) {
          if (didPop) {
            clearFormAndControllers();
          }
        },
        child: Scaffold(
          appBar: reusableAppBar(
            title: 'Add Bills',
            context: context,
            showBackButton: true,
          ),
          body: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
            child: ReusableColumn(
              children: <Widget>[
                BillDetailsAddBills(
                  controller: billDetailsControllers,
                ),
                const ReusableSizedBox(height: 15),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.itemDetails.length,
                  itemBuilder: (context, index) {
                    final controllersForThisItem = index < itemControllers.length
                        ? itemControllers[index]
                        : (() {
                      _addControllersForNewItem();
                      return itemControllers[index];
                    })();

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 15),
                      child: ItemDetailsAddBills(
                        index: index,
                        controllers: controllersForThisItem,
                      ),
                    );
                  },
                ),
                FormContainer(
                  height: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: PayzoBottomsheetNavigator(
                      isPayzoColor: true,
                      addButton: true,
                      title: 'Item Details',
                      trailing: 'Add New Line',
                      divider: false,
                      onTap: () async {
                        await ref.read(focusUtilsProvider).unfocusAndDelay();

                        final isValid = ref.read(addBillFormProvider.notifier).validateLastItemFields();

                        if (isValid) {
                          // 1) Add form model item
                          ref.read(addBillFormProvider.notifier).addNewItem();

                          // 2) Add controllers for new item (must be after state change)
                          _addControllersForNewItem();

                          // 3) update any counter provider if used
                          ref.read(addNewLineProvider.notifier).state++;
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Finish filling out the current item to add a new one.'),
                              duration: Duration(seconds: 2),
                            ),
                          );
                        }
                      },
                    ),
                  ),
                ),
                const ReusableSizedBox(height: 15),
                FormContainer(
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: ReusableColumn(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ReusableRow(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            SvgPictureWidget(image: 'assets/pin.svg', height: 24, width: 24),
                            const ReusableSizedBox(width: 10),
                            Expanded(
                              child: PayzoBottomsheetNavigator(
                                title: 'Attachments',
                                divider: false,
                                trailing: state.attachment?.path.split('/').last ?? 'Tap to Select',
                                onTap: () async {
                                  await ref.read(focusUtilsProvider).unfocusAndDelay();
                                  final result = await FilePicker.platform.pickFiles(
                                    type: FileType.custom,
                                    allowedExtensions: ['pdf', 'jpg', 'png', 'jpeg'],
                                  );
                                  if (result != null && result.files.single.path != null) {
                                    final pickedFile = File(result.files.single.path!);
                                    // notifier must accept File? for 'attachment'
                                    notifier.updateField('attachment', pickedFile);
                                  } else {
                                    debugPrint('❌ No file selected');
                                  }
                                },
                              ),
                            ),
                          ],
                        ),
                        if (state.attachment != null) ...[
                          const ReusableSizedBox(height: 12),
                          Padding(
                            padding: const EdgeInsets.only(left: 34.0),
                            child: ReusableRow(
                              children: [
                                const Icon(Icons.insert_drive_file_outlined, color: AppColors.appMainColor, size: 20),
                                const ReusableSizedBox(width: 8),
                                Expanded(
                                  child: ReusableText(
                                    text: state.attachment!.path.split('/').last,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    fontSize: 14,
                                    color: Colors.black87,
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    // Remove attachment: notifier.updateField must accept null for 'attachment'
                                    try {
                                      notifier.updateField('attachment', null);
                                    } catch (e) {
                                      debugPrint('Failed to clear attachment via updateField: $e');
                                      // fallback: clear entire form safely if needed
                                      notifier.clearForm();
                                    }
                                  },
                                  child: const Padding(
                                    padding: EdgeInsets.all(4.0),
                                    child: Icon(Icons.cancel_outlined, color: Colors.redAccent, size: 20),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                const ReusableSizedBox(height: 15),
                BillTotalWidget(),
              ],
            ),
          ),
          bottomNavigationBar: PayzoFormSubmitTwoButtons(
            safeArea: true,
            cancelText: 'Clear',
            saveText: 'Save',
            cancelOnPressed: () {
              notifier.clearForm();
              clearFormAndControllers();
              ref.read(addNewLineProvider.notifier).state = 1;
            },
            saveOnPressed: () async {
              notifier.validateForm();
              await Future.delayed(Duration.zero);

              final currentState = ref.read(addBillFormProvider);
              final file = currentState.attachment;

              if (currentState.errors.isEmpty) {
                showPayzoProgress(context: context);
                try {
                  final response = await ref.read(generateBillProvider(file).future);
                  Navigator.pop(context); // remove progress

                  // success dialog as before...
                  // <keep your existing success dialog code here>
                } catch (e, st) {
                  // Ensure progress dialog removed
                  try { Navigator.pop(context); } catch (_) {}

                  // Print to debug logs (ADB logcat viewable)
                  debugPrint('🚨 Submit failed: $e');
                  debugPrint('$st');

                  // Show user-visible dialog with shortened message and a "Details" button
                  // showDialog(
                  //   context: context,
                  //   builder: (_) => AlertDialog(
                  //     title: const Text("❌ Error"),
                  //     content: SingleChildScrollView(
                  //       child: Column(
                  //         crossAxisAlignment: CrossAxisAlignment.start,
                  //         children: [
                  //           Text(e.toString(), maxLines: 10, overflow: TextOverflow.ellipsis),
                  //           const SizedBox(height: 8),
                  //           const Text('Tap DETAILS to view full stack trace.'),
                  //         ],
                  //       ),
                  //     ),
                  //     actions: [
                  //       TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK")),
                  //       TextButton(
                  //         onPressed: () {
                  //           Navigator.pop(context);
                  //           // Show full error + stacktrace in a new dialog (copyable)
                  //           showDialog(
                  //             context: context,
                  //             builder: (_) => AlertDialog(
                  //               title: const Text("Error details"),
                  //               content: SingleChildScrollView(
                  //                 child: SelectableText('$e\n\n$st', style: const TextStyle(fontSize: 12)),
                  //               ),
                  //               actions: [
                  //                 TextButton(onPressed: () => Navigator.pop(context), child: const Text("Close")),
                  //               ],
                  //             ),
                  //           );
                  //         },
                  //         child: const Text("DETAILS"),
                  //       ),
                  //     ],
                  //   ),
                  // );
                }

              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please fill in all required fields')),
                );
              }
            },
          ),
        ),
      ),
    );
  }
}
